from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from consts import ModelName, Season, Dataset, Target, DISTRICTS
from tensorflow import keras
import pickle
import datetime
import json
import numpy as np
import pandas as pd
from db import get_location, find_nearest_n
from urllib.parse import unquote_plus


def get_current_season():
    if datetime.date.today().month in range(1,8): # jan-jul=kharif
        return Season.kharif
    else:
        return Season.rabi

def get_model(model_name: ModelName, season_name: Season):
    fn = {
        ModelName.random_forest: f"models/rfc_{season_name.value}.pickle",
        ModelName.k_nearest_neighbor: f"models/knn_{season_name.value}.pickle",
        ModelName.naive_bayes: f"models/nb_{season_name.value}.pickle",
        ModelName.neural_network: f"models/ann_{season_name.value}.keras",
        ModelName.svm: f"models/svm_{season_name.value}.pickle"
    }
    model = None
    if model_name in [ModelName.svm, ModelName.k_nearest_neighbor, ModelName.naive_bayes, ModelName.random_forest]:
        with open(fn[model_name], 'rb') as f:
            model = pickle.load(f)
    elif model_name is ModelName.neural_network:
        model = keras.models.load_model(fn[model_name])
    else:
        raise HTTPException(status_code=400, detail="Invalid Model")
    return model

def mask(factors, inp, mean):
    if 'temp' in factors: factors.extend(['temp_min', 'temp_max'])
    vals = []
    i = 0
    for f in ['ndwi', 'smi', 'ph', 'pcontent', 'salinity', 'gwl', 'temp_min', 'temp_max', 'humidity', 'rainfall']:
        v = inp[f] if f in factors else mean[i]
        if not v: v = mean[i]
        vals.append(v)
        i+=1
    return vals

msp_data = None
with open("msp.json") as fp:
    msp_data = json.load(fp)
yield_data = pd.read_csv("yield.csv")
yield_data = yield_data.replace('-', 0)
def add_yield_and_msp(crop, district):
    l = list(crop)
    l.append(msp_data[l[0]])
    l.append(yield_data.loc[yield_data.District==district, l[0]].item())
    return l
    
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*']
)

@app.get("/features")
async def features(lat: float = 26.9124, lng: float = 75.7873):
    s = get_current_season()
    return find_nearest_n(s, lat, lng)

@app.get("/models")
async def models():
    return ModelName.describe()

@app.get("/recommend")
async def recommend(
    model_name: ModelName, 
    locationid: int = 1,
    factors: str = '"ndwi,salinity,smi,pcontent,ph,gwl"',
    target: Target=None,
    season: Season= None):
    
    s = season or get_current_season()
    dataset = Dataset(s)
    model = get_model(model_name, s)

    # fetch location record from db, mask and normalize
    inp = get_location(locationid)
    factors = unquote_plus(factors[1:-1]).split(',')
    inp_arr = mask(factors, inp, dataset.mean)

    inp_norm = (np.array(inp_arr) - dataset.mean) / dataset.std
    inp_norm = np.expand_dims(inp_norm, 0)
    if model_name is ModelName.neural_network:
        out = model.predict(inp_norm)
    elif model_name in [ModelName.naive_bayes, ModelName.random_forest, ModelName.svm, ModelName.k_nearest_neighbor]:
        out = model.predict_proba(inp_norm)
    else:
        raise HTTPException(status_code=400, detail="Invalid model")

    if out.ndim > 1: out = np.squeeze(out)
    crops = list(zip(dataset.labels.astype(str), out.astype(float)))
    crops = list(map(add_yield_and_msp, crops, [DISTRICTS[inp['district']]] * len(crops)))

    k = lambda x: x[1]
    if target is Target.income:
        k = lambda x: int(x[2])*int(x[3])
    elif target is Target.cropyield:
        k = lambda x: int(x[3])
    crops = sorted(crops, reverse=True, key=k)

    return {'crops': crops}
