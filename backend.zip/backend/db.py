from consts import Season

from urllib.parse import quote_plus

import sqlalchemy as sa
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, Integer, Float
from sqlalchemy import func

from geoalchemy2 import Geometry
from geoalchemy2 import functions as geofunc
from geoalchemy2.comparator import Comparator
from geoalchemy2.shape import to_shape

#ip route show | grep -i default | awk '{ print $3}'
CONN_STR = "postgresql://postgres:%s@172.19.240.1/croprecommendation" % quote_plus("lavika@123")
engine = sa.create_engine(CONN_STR, echo=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class Location(Base):
    __tablename__ = "location"
    id = Column(Integer, primary_key=True)
    season = Column(Integer)
    geom = Column(Geometry('POINT'))
    
    ndwi = Column(Float)
    smi = Column(Float)
    gwl = Column(Float)
    pcontent = Column(Float)
    ph = Column(Float)
    salinity = Column(Float)
    
    claycontent = Column(Float)
    sandcontent = Column(Float)
    somcontent = Column(Float)
    soccontent = Column(Float)
    ncontent = Column(Float)
    kcontent = Column(Float)
    ndmi = Column(Float)
    bsi = Column(Float)
    tgsi = Column(Float)
    lst = Column(Float)
    
    district = Column(Integer)
    rainfall = Column(Float)
    humidity = Column(Float)
    temp_min = Column(Float)
    temp_max = Column(Float)

    b1 = Column(Float)
    b2 = Column(Float)
    b3 = Column(Float)
    b4 = Column(Float)
    b5 = Column(Float)
    b6 = Column(Float)
    b7 = Column(Float)
    b10 = Column(Float)

    def to_tuple(self):
        return (self.id, to_shape(self.geom).wkt, self.ndwi, self.smi, self.gwl, 
                self.ph, self.pcontent, self.salinity, self.rainfall, self.humidity, 
                self.temp_min, self.temp_max)
    
    def to_dict(self):
        return {
            'id': self.id,
            'latlng': to_shape(self.geom).wkt,
            'district': self.district,

            'ndwi': self.ndwi,
            'smi': self.smi,
            'gwl': self.gwl,
            'ph': self.ph,
            'pcontent': self.pcontent,
            'salinity': self.salinity,
            
            'claycontent': self.claycontent,
            'sandcontent': self.sandcontent,
            'ncontent': self.ncontent,
            'kcontent': self.kcontent,
            'somcontent': self.somcontent,
            'soccontent': self.soccontent,
            'ndmi': self.ndmi,
            'bsi': self.bsi,
            'tgsi': self.tgsi,
            'lst': self.lst,

            'rainfall': self.rainfall,
            'humidity': self.humidity,
            'temp_min': self.temp_min,
            'temp_max': self.temp_max,

            'b1': self.b1,
            'b2': self.b2,
            'b3': self.b3,
            'b4': self.b4,
            'b5': self.b5,
            'b6': self.b6,
            'b7': self.b7,
            'b10': self.b10
        }

def find_nearest_n(season, lat, lng, n=5):
    s = 0 if season is Season.kharif else 1
    with SessionLocal() as session:
        query = session.query(Location).where(Location.season == s).order_by(Comparator.distance_centroid(Location.geom, f'POINT({lat} {lng})')).limit(n)
        return [l.to_dict() for l in query]

def get_location(locationid):
    with SessionLocal() as session:
        items = sa.select(Location).where(Location.id==locationid)
        locations = session.scalars(items)
        locations = [l for l in locations]
        if len(locations): return locations[0].to_dict()
        else: return None
