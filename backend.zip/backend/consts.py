from enum import Enum
import numpy as np

class Season(str, Enum):
    rabi = "rabi"
    kharif = "kharif"

class Target(str, Enum):
    income = "income"
    cropyield = "yield"

class ModelName(str, Enum):
    naive_bayes = "nb"
    svm = "svm"
    random_forest = "rfc"
    k_nearest_neighbor = "knn"
    neural_network = "ann"

    @classmethod
    def describe(cls):
        return [
            {
                "name": "Neural Network",
                "description": "Moderate speed, High convergence, Low error rate",
                "value": ModelName.neural_network,
            },
            {
                "name": "K-Nearest Neighbour",
                "description": "Slow speed, High convergence, Low error rate",
                "value": ModelName.k_nearest_neighbor,
            },
            {
                "name": "Support Vector Machine (SVM)",
                "description": "Fast speed, Low convergence, High error rate",
                "value": ModelName.svm,
            },
            {
                "name": "Random Forest",
                "description": "Moderate speed, Low convergence, High error rate",
                "value": ModelName.random_forest,
            },
            {
                "name": "Naive Bayes",
                "description": "Fast speed, Moderate convergence, Medium error rate",
                "value": ModelName.naive_bayes,
            }
        ]

kharif_crops = ["Black Gram", "Castor", "Corn", "Cotton", "Cowpea", "Flax", "Green Gram", "Groundnut", "Cluster Bean", "Matbean", "Onion", "Pearl Millet", "Rice", "Sesame", "Sorghum", "Soybean"]
kharif_mean = [-4.04069411e-01,  4.01994157e-01,  6.59089070e+00, 9.20399936e+05, 4.60802045e-01,
            1.83498506e+00, 2.46628906e+01,  3.30080554e+01, 6.63867286e+01, 6.76351265e+02]
kharif_std = [1.19198487e-01, 2.45473605e-01, 1.75163693e+00, 1.70775957e+08, 8.37910026e-02, 
            2.06259070e-01, 5.81931038e-01, 9.35808320e-01, 3.84700571e+00, 2.51316109e+02]

rabi_crops = ['Barley', 'Coriander', 'Cumin', 'Fenugreek', 'Gram', 'Linseed', 'Masur', 'Mustard', 'Onion', 'Potato', 'Sunflower', 'Taramira', 'Wheat']
rabi_mean = [-3.85043928e-01,  4.10931775e-01,  7.05738460e+00, 1.54803760e-02,  4.97654030e-01,
            1.76751298e+00, 1.62950282e+01,  3.05260835e+01,  4.26207705e+01, 4.19922314e+01]
rabi_std = [0.10554567,  0.21535849,  1.5086681 ,  0.10458691,  0.08952986,
            0.20257969,  0.75153879,  0.84363171,  5.53910541, 21.82757004]

class Dataset:
    def __init__(self, season:Season):
        self.season = season
    
    @property
    def labels(self):
        out = rabi_crops if self.season == Season.rabi else kharif_crops
        return np.array(out)

    @property
    def mean(self):
        out = rabi_mean if self.season == Season.rabi else kharif_mean
        return np.array(out)

    @property
    def std(self):
        out = rabi_std if self.season == Season.rabi else kharif_std
        return np.array(out)

DISTRICTS = ["Ajmer","Alwar","Banswara","Baran","Barmer","Bharatpur","Bhilwara","Bikaner","Bundi",
             "Chittorgarh","Churu","Dausa","Dholpur","Dungarpur","Ganganagar","Hanumangarh","Jaipur",
             "Jaisalmer","Jalore","Jhalawar","Jhunjhunu","Jodhpur","Karauli","Kota","Nagaur","Pali",
             "Pratapgarh","Rajsamand","Sawai Madhopur","Sikar","Sirohi","Tonk","Udaipur"]