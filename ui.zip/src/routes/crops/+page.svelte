<script>
  import { t } from "$lib/i18n";
  import majorcrops from "$lib/majorcrops";

  let cols = [0, 1, 2, 3]
</script>

<section class="section">
  <div class="container">
    <h1 class="title">{$t('nav.crops')}</h1>
    {$t('crops.desc')}
    <div class="columns">
      {#each cols as col}
        <div class="column is-3">
          {#each Object.entries(majorcrops).slice(col*9, (col+1)*9) as [district, crops]}
            <div class="card m-1">
              <header class="card-header"><p class="card-header-title">
                {$t('districts.' + district.toLowerCase().replace(/ /g,''))}
              </p></header>
              <div class="content">
                <ul>
                  {#each crops as crop}
                    <li>{$t('crops.' + crop.toLowerCase().replace(/ /g,''))}</li>
                  {/each}
                </ul>
              </div>
            </div>
          {/each}
        </div>
      {/each}
    </div>
  </div>
</section>
