<script>
    import { t } from "$lib/i18n";
</script>
<section class="hero">
  <div class="hero-head">
    <figure class="image is-3by1">
      <img src="/img/crops.jpg" alt="Crops" />
    </figure>
  </div>
</section>
<section class="section">
  <div class="container has-text-centered">    
    <p class="title">{$t('home.welcome')}</p>
    <p class="content" align="justify">
      {$t('home.desc')}
    </p>
    <a href="/location" class="button is-warning"><strong>{$t('home.button')}</strong></a>
  </div>
</section>
