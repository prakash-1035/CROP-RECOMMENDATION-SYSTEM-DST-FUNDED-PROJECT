<script>
  import { t } from "$lib/i18n";
  
  export let data;
  const urlParams = new URLSearchParams(window.location.search);
  const target = urlParams.get('target');
  
  let crops = [...data.crops];
  let sortByConfidence = false;
  function setSortByConfidence(b) {
    sortByConfidence = b;
    if (sortByConfidence) {
      crops = [...data.crops];
      crops.sort((a,b) => b[1] - a[1]);
      crops = crops;
    }
    else {
      crops = [...data.crops];
    }
  }

</script>
<div class="columns">
  <div class="container column is-8">
    <div class="m-3">
      <h1 class="title">{$t('results.header')}</h1>
      <div class="content">
        {$t('results.desc')}
        <br/>

        <div class="ml-5">
          {#each crops as crop (crop[0])}
            {#if crop[1] > 0.01}
              <div class="crop">
                <article class="media">
                  <div class="media-left">
                    <figure class="image is-64x64">
                      <img src="/img/crops/{crop[0].toLowerCase().replace(/ /g,'')}.jpg" />
                    </figure>
                  </div>
                  <div class="media-content">
                    <div class="content">
                      <p>
                        <strong>{$t('crops.' + crop[0].toLowerCase().replace(/ /g,''))}</strong>&nbsp;({crop[1] < 0.01 ? '<0.1' : (crop[1] * 100).toFixed(2)}%)<br/>
                        {#if target == "income"}
                          ₹{(crop[2] * crop[3] / 100).toLocaleString()}/ha @ {crop[3].toLocaleString()} kg/ha
                        {:else if target == "yield"}
                          {crop[3].toLocaleString()} kg/ha
                        {:else}
                          {crop[1] < 0.01 ? '<0.1' : (crop[1] * 100).toFixed(2)}%
                        {/if}
                      </p>
                    </div>
                  </div>
                </article>
              </div>
            {/if}
          {/each}
        </div>        
        <div class="tabs is-toggle p-0 m-0">
          <ul>
            {$t('results.sortby')} &nbsp;
            <li class:is-active={!sortByConfidence} on:click={() => setSortByConfidence(false)}><a>{$t('results.' + target)}</a></li>
            <li class:is-active={sortByConfidence} on:click={() => setSortByConfidence(true)}><a>{$t('results.confidence')}</a></li>
          </ul>
        </div>
      </div>
      <a class="button" href="/location">{$t('common.back')}</a>
    </div>
  </div>

  <div class="column is-4 has-background-light">
    <div class="box m-3">
      <figure class="image">
        <img src="/img/nasscomagri.png" />
      </figure>
    </div>
    <div class="box m-3">
      <figure class="image">
        <img src="/img/indiaagri1.jpg" />
        <img src="/img/indiaagri2.jpg" />
      </figure>
    </div>

  </div>
</div>

<style>
  .box {
    border: solid 1px gray;
  }
  .crop {
    border: solid 1px gray;
    border-radius: 5px;
    margin-top: 5px;
    width: 80%;
  }
  figure {
    margin-left: 0px;
  }
</style>