import { get_recommendation } from '$lib/Server.js'

export function load({fetch, url}) {
    const model_name = url.searchParams.get("model");
    const locationid = url.searchParams.get("locationid");
    const target = url.searchParams.get("target");
    const factors = url.searchParams.get("factors");
    return get_recommendation(fetch, model_name, locationid, target, factors);
}
