import { get_models } from '$lib/Server.js'

export function load({fetch}) {
    return {models: get_models(fetch)};
}
