<script>
  import DefinitionCheckList from "../../lib/DefinitionCheckList.svelte";
  import { t } from "$lib/i18n";

  export let data;
  const urlParams = new URLSearchParams(window.location.search);

</script>
<div class="columns">
  <div class="container column is-8">
    <div class="m-3">
      <h1 class="title">{$t('models.header')}</h1>

      <form action="/results" method="GET">
        <div class="field">
          <label class="label">{$t('models.desc')}</label>
          <div class="control">
            <DefinitionCheckList name="model" items={data.models} radio={true} />
          </div>
        </div>

        <div class="field">
          <label class="label">Optimize For</label>
          <div class="control">
            <label class="radio">
              <input type="radio" name="target" value="income" checked /> Income
            </label>
            <label class="radio">
              <input type="radio" name="target" value="yield" /> Yield
            </label>
          </div>
        </div>
        
        <input type="text" name="locationid" value={urlParams.get('locationid')} hidden />
        <input type="text" name="factors" value={urlParams.getAll('factors')} hidden />

        <div class="field">
          <div class="control">
            <button class="button is-warning"><strong>{$t('common.next')}</strong></button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <div class="column is-4 has-background-light">
    <div class="m-3">
      <div class="box">
        <figure class="image">
          <a target="_blank" href="/img/remotesensing.png"><img src="/img/remotesensing.png" /></a>
          <figcaption>{$t('models.caption')}</figcaption>
        </figure>
      </div>
      <div class="box">
        <b>Technology in Agriculture:</b>
        <ul>
          <li>Makes lives easier</li>
          <li>Reduces labour</li>
          <li>Increases diversity</li>
          <li>Increases availability</li>
          <li>Improves mechanism</li>
          <li>Increases communication</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<style>
  .box {
    border: solid 1px gray;
  }
  ul {
    list-style-type: disc;
  }
</style>