<script>
  import Map from "$lib/Map.svelte";
  import { t } from "$lib/i18n";
  
  let mapVisible = false;
  function enableMap() {
    mapVisible = true;
  }

  let mapLocation = null;
  let lat = null, lng = null;
  function handleMapMove(e) {
    lat = e.detail.lat.toFixed(4);
    lng = e.detail.lng.toFixed(4);
    mapLocation = lat.toString() + "N" + lng.toString() + "E";
  }
</script>

<div class="columns">
  <div class="container column is-8">
    <div class="m-3">
      <h1 class="title">{$t('location.header')}</h1>
      <form action="/factors" method="GET">
        <!-- Font awesome: ntuxyaoomqkktxwsud@cwmxc.com -->
        <div class="columns">
          <div class="column field is-8">
            <label class="label">{$t('location.location')}</label>
            <div class="control has-icons-left">
              <input name="location" class="input is-rounded is-clickable" placeholder={$t('location.placeholder')} readonly on:click={enableMap} value={mapLocation} />
              <span class="icon is-left">
                <i class="fa fa-map-marker"></i>
              </span>
            </div>
          </div>
        </div>

        {#if mapVisible}
          <Map on:mapmove={handleMapMove} />
        {/if}
        
        <div class="field">
          <div class="control">
            <button class="button is-warning" disabled={!mapLocation}><strong>{$t('common.next')}</strong></button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="column is-4 has-background-light">
    <div class="m-3">
      <figure class="image box">
        <a href="/crops"><img src="/img/rajasthan.jpg" /></a>
        <figcaption>{$t('location.caption')}</figcaption>
      </figure>

      {$t('location.relatedlinks')}
      <ul>
        <li><a target="_blank" href="https://www.youtube.com/@DDKisan">{$t('location.link1')}</a></li>
        <li><a target="_blank" href="https://rajkisan.rajasthan.gov.in/">{$t('location.link2')}</a></li>
        <li><a target="_blank" href="https://agriwelfare.gov.in/">{$t('location.link3')}</a></li>
        <li><a target="_blank" href="https://scholar.google.co.in/scholar?hl=en&q=agriculture+india">{$t('location.link4')}</a></li>
        <li><a target="_blank" href="https://rajas.rajasthan.gov.in/PDF/2202024124440PMAgriculturalStatistics.pdf">{$t('location.link5')}</a></li>
      </ul>
    </div>
  </div>
</div>

<style>
  .box {
    border: solid 1px gray;
  }
  ul {
    list-style-type: disc;
  }
</style>