<script>
  import { t } from "$lib/i18n";
</script>
<section class="section">
  <div class="container">
    <h1 class="title">{$t('nav.schemes')}</h1>
    <div class="columns">
      <div class="column is-4">
        <a target="_blank" href="https://agriwelfare.gov.in/en/GuideAgriMkt" class="button is-fullwidth"><u>{$t('schemes.am')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideagriculturecensus" class="button is-fullwidth"><u>{$t('schemes.ac')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/GuideCredit" class="button is-fullwidth"><u>{$t('schemes.cr')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/GuideCropsnfsm" class="button is-fullwidth"><u>{$t('schemes.cn')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guiddroughtmanagement" class="button is-fullwidth"><u>{$t('schemes.dm')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideeconomicadministration" class="button is-fullwidth"><u>{$t('schemes.ea')}</u></a><br/>
      </div>
      <div class="column is-4">
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideextension" class="button is-fullwidth"><u>{$t('schemes.ex')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guidehorticulture" class="button is-fullwidth"><u>{$t('schemes.hc')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideinformationtechnology" class="button is-fullwidth"><u>{$t('schemes.it')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideintegratednutrient" class="button is-fullwidth"><u>{$t('schemes.in')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/GuideCooperation" class="button is-fullwidth"><u>{$t('schemes.ip')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guidemechanization" class="button is-fullwidth"><u>{$t('schemes.mt')}</u></a><br/>
      </div>
      <div class="column is-4">
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guidenaturalresourcemanagement" class="button is-fullwidth"><u>{$t('schemes.nr')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideoilseeds" class="button is-fullwidth"><u>{$t('schemes.od')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guideplantprotection" class="button is-fullwidth"><u>{$t('schemes.pp')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guiderainfedfarmingsystem" class="button is-fullwidth"><u>{$t('schemes.rf')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/Guiderashtriya" class="button is-fullwidth"><u>{$t('schemes.rk')}</u></a><br/>
        <a target="_blank" href="https://agriwelfare.gov.in/en/GuideSeeds" class="button is-fullwidth"><u>{$t('schemes.sd')}</u></a><br/>
      </div>
    </div>
  </div>
</section>
