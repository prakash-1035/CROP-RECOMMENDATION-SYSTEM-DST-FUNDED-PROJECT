<script>
  import NavBar from "$lib/NavBar.svelte";
</script>

<NavBar />
<slot />
<footer class="footer columns is-mobile is-centered has-background-light">
  <figure class="image column is-8-mobile">
    <img class="image" src="/img/dst.jpg" alt="DST logo" style="height:10vh;width:auto;margin:auto" />
  </figure>
  <figure class="image column is-4-mobile">
    <img class="image" src="/img/serb.jpg" alt="SERB logo" style="height:10vh;width:auto;margin:auto" />
  </figure>
</footer>