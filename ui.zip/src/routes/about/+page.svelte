<script>
      import { t } from "$lib/i18n";
</script>

<section class="section">
  <div class="container">
    <h1 class="title">{$t('nav.about')}</h1>
    <div class="columns">
      <div class="column is-narrow has-text-centered">
        <img src="img/mnit.png" alt="MNIT logo" class="image is-128x128 is-rounded is-inline-block" />
      </div>
      <div class="column">
        <p align="justify" class="content">
          {$t('about.text')}
        </p>
      </div>
    </div>
    <p align="justify" class="content">
      {$t('about.text2')}
    </p>
    <div class="content">
      <ul class="list">
        <li>Malaviya National Institute of Technology, Jaipur</li>
        <li>Department of Science and Technology, GoI</li>
        <li>Statistics Department, GoR</li>
        <li>Dynamic World</li>
        <li>Google Earth Engine</li>
        <li>Open Meteo</li>
      </ul>    
    </div>
  </div>
</section>
