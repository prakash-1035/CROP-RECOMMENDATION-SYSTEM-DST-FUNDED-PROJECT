import { get_features } from '$lib/Server.js'

export function load({fetch, url}) {
    const location = url.searchParams.get("location").split("N");
    const lat=location[0], lng=location[1].substr(0,7);
    return {features: get_features(fetch, lat, lng)};
}
