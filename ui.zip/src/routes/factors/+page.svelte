<script>
    import DefinitionCheckList from "$lib/DefinitionCheckList.svelte";
    import { t } from "$lib/i18n";

    export let data;
    $: factors = [
      {
        name: $t('factors.ndwi'),
        description: $t('factors.ndwidesc'),
        value: "ndwi",
        checked: true
      },
      {
        name: $t('factors.salinity'),
        description: $t('factors.salinitydesc'),
        value: "salinity",
        checked: true
      },
      {
        name: $t('factors.smi'),
        description: $t('factors.smidesc'),
        value: "smi",
        checked: true
      },
      {
        name: $t('factors.pcontent'),
        description: $t('factors.pcontentdesc'),
        value: "pcontent",
        checked: true
      },
      {
        name: $t('factors.ph'),
        description: $t('factors.phdesc'),
        value: "ph",
        checked: true
      },
      {
        name: $t('factors.gwl'),
        description: $t('factors.gwldesc'),
        value: "gwl",
        checked: true
      },
      {
        name: $t('factors.humidity'),
        description: $t('factors.humiditydesc'),
        value: "humidity",
        checked: true
      },
      {
        name: $t('factors.rainfall'),
        description: $t('factors.rainfalldesc'),
        value: "rainfall",
        checked: true
      },
      {
        name: $t('factors.temp'),
        description: $t('factors.tempdesc'),
        value: "temp",
        checked: true
      }
    ];

    let locationId = null;
    function handleLocationSelect(e) {
      locationId = e.target.value;
    }

    let showFactors = false;
    function showNext(e) {
      showFactors = true;
      e.preventDefault();
    }
</script>

<form action="/models" method="GET">
<section class="section" class:is-hidden={showFactors}>
  <h1 class="title">{$t('factors.header')}</h1>
    {$t('factors.desc')}
  <table class="table is-bordered is-narrow is-fullwidth">
    <tbody>
      <tr>
        <th></th>
        <th>(Latitude Longitude)</th>
        <th>{$t('factors.ndwi')}</th>
        <th>{$t('factors.smi')}</th>
        <th>{$t('factors.gwl')}</th>
        <th>{$t('factors.ph')}</th>
        <th>{$t('factors.pcontent')}</th>
        <th>{$t('factors.salinity')}</th>
        <th>{$t('factors.rainfall')}</th>
        <th>{$t('factors.humidity')}</th>
        <th>{$t('factors.temp') + '(' + $t('factors.min') + ')'}</th>
        <th>{$t('factors.temp') + '(' + $t('factors.max') + ')'}</th>
      </tr>
      {#each data.features as item}
        <tr>
          <td><input type="radio" name="locationid" value="{item[0]}" on:click={handleLocationSelect} /></td>
          <td>{item[1].substring(5)}</td>
          <td>{item[2].toFixed(2)}</td>
          <td>{item[3].toFixed(2)}</td>
          <td>{item[4].toFixed(2)}</td>
          <td>{item[5].toFixed(2)}</td>
          <td>{item[6].toExponential(2)}</td>
          <td>{item[7].toFixed(2)}</td>
          <td>{item[8]?.toFixed(2)}</td>
          <td>{item[9]?.toFixed(2)}</td>
          <td>{item[10]?.toFixed(2)}</td>
          <td>{item[11]?.toFixed(2)}</td>
        </tr>
      {/each}
    </tbody>
  </table>
  <button class="button is-warning" disabled={!locationId} on:click={showNext}>{$t('common.next')}</button>
</section>

<section class="section columns" class:is-hidden={!showFactors}>
  <div class="container column is-6">
    <h1 class="title">{$t('factors.header2')}</h1>
    
      <div class="field">
        <label class="label">{$t('factors.desc2')}</label>
        <div class="control">
          <DefinitionCheckList name="factors" items={factors} />
        </div>
      </div>

      <div class="field">
        <div class="control">
          <button class="button is-warning"><strong>{$t('common.next')}</strong></button>
        </div>
      </div>
  </div>

  <div class="column is-6">
    <div class="box">
      <figure class="image">
        <a target="_blank" href="/img/rabidata.png"><img src="/img/rabidata.png" /></a>
        <figcaption>{$t('factors.rabicaption')}</figcaption>
      </figure>
    </div>
    <div class="box">
      <figure class="image">
        <a target="_blank" href="/img/kharifdata.png"><img src="/img/kharifdata.png" /></a>
        <figcaption>{$t('factors.kharifcaption')}</figcaption>
      </figure>
    </div>
  </div>
</section>
</form>


<style>
  .box {
    border: solid 1px gray;
  }
</style>