<script>
  import { onMount } from "svelte";
  import {createEventDispatcher} from "svelte";
  const dispatch = createEventDispatcher();

  let lat = 26.8490, lng = 75.7713; //Jaipur
  onMount(() => {
    var map = L.map('map', {attributionControl:false, keyboard:false}).setView([lat, lng], 15);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 17,
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    var marker = L.marker([lat, lng], {
      draggable: true, 
      autoPan: true, 
      keyboard: false,
      title: 'Drag to set location'
    }).addTo(map);
    marker.on('move', (e) => {
      lat = e.latlng.lat;
      lng = e.latlng.lng;
      dispatch('mapmove', {lat, lng});
    });

    map.on('locationfound', (e)=>{
      lat = e.latlng.lat;
      lng = e.latlng.lng;
      map.setView(e.latlng);
      marker.setLatLng(e.latlng);
    });
    map.on('locationerror', (e)=>{
      console.warn("Location error.", e);
      marker.setLatLng(L.latLng(lat, lng));
    });
    map.locate();
  });
</script>

<div class="block" id="map" style="height:80vmin; width:80vmin;">
</div>
