<script>
  /*
  name: name of form element
  items: array of objects where each object is of the following format:
  {value, name, description, checked}
  radio: boolean, to describe if only one selection is possible
  */
  import {beforeUpdate} from 'svelte';

  export let name;
  export let items = [];
  export let radio = false;
  export let hidden = false;

  beforeUpdate(() => {
    console.log("beforeUpdate");
    if (radio) {
      let oneChecked = false;
      for (let item of items) {
        if (item.checked) oneChecked = true;
      }
      if (!oneChecked && items.length) {
        items[0].checked = true;
        items = [...items];
      }
    }
  });

  function handleClick(e, item) {
    if (radio) {
      items.forEach((i) => i.checked = false);
    }
    item.checked = !item.checked;
    items = [...items];
  }
</script>

{#each items as item (item.value)}
  <div class="box dcl-item is-clickable mb-1" class:dcl-is-selected={item.checked} on:click={(e) => handleClick(e, item)}>
    <input type={radio?"radio":"checkbox"} name={name} value={item.value} checked={item.checked} hidden={hidden} />
    <strong>{item.name}</strong><br/>
    {item.description}
  </div>
{/each}

<style>
  .dcl-item {
    border-left: #ccc solid 0.5rem;
  }
  .dcl-is-selected {
    border-left: green solid 0.5rem;
  }
</style>