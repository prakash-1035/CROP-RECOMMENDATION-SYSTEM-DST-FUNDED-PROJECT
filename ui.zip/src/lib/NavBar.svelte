<script>
  import {fade} from 'svelte/transition';
  import { t, locale } from "./i18n";

  let menuVisible = false;
  function toggleMenu() {
    menuVisible = !menuVisible;
  }

  function toggleLocale() {
    locale.set(($locale == "en") ? "hi" : "en");
    menuVisible = !menuVisible;
  }
</script>

<nav class="navbar is-success is-fixed-top" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item" href="/">
      <figure class="image is-64x64"><img class="is-rounded" src="/img/mnit.png" height="100%" /></figure>
      <p class="is-large" style="font-size: 2rem"><strong>&nbsp;{$t('nav.title')}</strong></p>
    </a>
    <a class="navbar-burger" role="button" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample" on:click={toggleMenu}>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
    </a>
  </div>

  <div class="navbar-menu" class:is-active={menuVisible} id="navbarBasicExample" transition:fade>    
    <div class="navbar-end">
      <a class="navbar-item" href="/" on:click={toggleMenu}>{$t('nav.home')}</a>
      <a class="navbar-item" href="/crops" on:click={toggleMenu}>{$t('nav.crops')}</a>
      <a class="navbar-item" href="/schemes" on:click={toggleMenu}>{$t('nav.schemes')}</a>
      <a class="navbar-item" href="/about" on:click={toggleMenu}>{$t('nav.about')}</a>
      <a class="navbar-item" on:click={toggleLocale}>
        <span class="icon-text">
          <span class="icon">
            <i class="fa fa-language"></i>
          </span>
          <span>{$locale=="en"?"हिंदी":"Eng"}</span>
        </span>
      </a>
    </div>
  </div>
</nav>
